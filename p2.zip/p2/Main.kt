fun main(){

    var browser= KidsBrowser()
    browser.start()

}